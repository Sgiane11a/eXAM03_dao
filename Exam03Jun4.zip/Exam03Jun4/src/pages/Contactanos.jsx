
import React, { useEffect, useState } from 'react';
import HeroStatic from '../components/HeroStatic';

function Contactanos() {
    return(
        <HeroStatic />
    )
}
export default Contactanos;