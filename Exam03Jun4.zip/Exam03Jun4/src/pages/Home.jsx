import React, { useEffect, useState } from 'react';
import HeroCarousel from '../components/HeroCarousel';
import templatesData from '../data/templates.json';

const Home = () => {
  const [templates, setTemplates] = useState([]);

  useEffect(() => {
    setTemplates(templatesData);
  }, []);

  return (
    <div className="container my-4">
      <HeroCarousel templates={templates} />
    </div>

    
  );
};

export default Home;
