import React, { useEffect, useState } from 'react';
import SearchBar from '../components/SearchBar';
import CategoryGrid from '../components/CategoryGrid';
import categoriesData from '../data/categories.json';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    setCategories(categoriesData);
  }, []);

  const filtered = categories.filter(cat =>
    cat.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="container my-4">
      <h2 className="mb-4">Categorías de pinterest</h2>
      <SearchBar query={query} setQuery={setQuery} />
      <CategoryGrid categories={filtered} />
    </div>
  );
};

export default Categories;
