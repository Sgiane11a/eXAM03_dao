import React from 'react';
import { Form, FormControl } from 'react-bootstrap';

const SearchBar = ({ query, setQuery }) => {
  return (
    <Form className="mb-4">
      <FormControl
        type="search"
        placeholder="Buscar categorías como comida, libros..."
        value={query}
        onChange={e => setQuery(e.target.value)}
      />
    </Form>
  );
};

export default SearchBar;
