import React from 'react';
import { Card, Col, Row } from 'react-bootstrap';

const CategoryGrid = ({ categories }) => {
  return (
    <Row xs={1} sm={2} md={3} lg={4} className="g-4">
      {categories.map(({ id, name, image }) => (
        <Col key={id}>
          <Card className="h-100 shadow-sm">
            <Card.Img variant="top" src={image} alt={name} style={{height: '180px', objectFit: 'cover'}} />
            <Card.Body>
              <Card.Title>{name}</Card.Title>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default CategoryGrid;
