// src/components/Footer.jsx
import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const Footer = () => {
  return (
    <footer className="bg-dark text-light py-4 mt-auto">
      <Container>
        <Row>
          <Col md={6}>
            <h5>PINTEREST</h5>
            <p>© Elabrado por Gianella Cordova Apolinario el 04/06/2025</p>
          </Col>
          <Col>
            
          </Col>
          <Col md={6} className="text-md-end">
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-light me-3">
              Twitter
            </a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-light me-3">
              Facebook
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-light">
              Instagram
            </a>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
