import React from 'react';
import { Carousel } from 'react-bootstrap';

const HeroCarousel = ({ templates }) => {
  return (
    <Carousel>
      {templates.map(({ id, title, image }) => (
        <Carousel.Item key={id}>
          <img
            className="d-block w-100"
            src={image}
            alt={title}
            style={{ maxHeight: '500px', objectFit: 'cover' }}
          />
          <Carousel.Caption>
            <h3>{title}</h3>
          </Carousel.Caption>
        </Carousel.Item>
      ))}
    </Carousel>
  );
};

export default HeroCarousel;
