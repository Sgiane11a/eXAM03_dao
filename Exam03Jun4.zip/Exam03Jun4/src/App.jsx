import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Categories from './pages/Categories';
import { Navbar, Container, Nav } from 'react-bootstrap';
import Footer from "./components/Footer";
import Contactanos from './pages/Contactanos';

const App = () => {
  return (
    <BrowserRouter>
      <div className="d-flex flex-column min-vh-100">
        <Navbar bg="light" expand="lg" className="mb-4">
          <Container>
            <Navbar.Brand as={Link} to="/">Pinterest Grid App</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav>
                <Nav.Link as={Link} to="/">Inicio</Nav.Link>
                <Nav.Link as={Link} to="/categories">Categorías</Nav.Link>
                <Nav.Link as={Link} to="/contactanos">Contactanos</Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>

        <main className="flex-grow-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/contactanos" element={<Contactanos />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </BrowserRouter>
  );
};

export default App;
